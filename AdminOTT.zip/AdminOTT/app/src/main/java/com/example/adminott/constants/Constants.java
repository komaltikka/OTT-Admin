package com.example.adminott.constants;

public class Constants {

    public static class baseUrl{

public final static String BASE_URL="http://myleader.sparsematrix.co.in/ott/";
    }

}
