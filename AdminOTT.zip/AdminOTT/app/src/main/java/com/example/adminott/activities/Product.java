package com.example.adminott.activities;
public class Product {

    private String pName;
    private int pImage;
    private String pOffer;

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getpImage() {
        return pImage;
    }

    public void setpImage(int pImage) {
        this.pImage = pImage;
    }

    public String getpOffer() {
        return pOffer;
    }

    public void setpOffer(String pOffer) {
        this.pOffer = pOffer;
    }


}

